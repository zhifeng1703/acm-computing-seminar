using PyPlot
using DelimitedFiles

data=readdlm("data.txt")
fontsize_title=24;
fontsize_legend=14;
fontsize_axis=16;
fontsize_ticks=14;

fig=figure(figsize=(10,10))

plot(data[:,1],data[:,3],linestyle="--",marker="o",label=L"R_N")
plot(data[:,1],data[:,4],label="Bound")
title("Log plot of "*L"R_N"*" and the bound "*L"1/N",fontsize=fontsize_title)
legend(loc="upper right",fontsize=fontsize_legend)
yscale("log")
xscale("log")
grid("on")
xlabel("N",fontsize=fontsize_axis)
ylabel("Residue",fontsize=fontsize_axis)

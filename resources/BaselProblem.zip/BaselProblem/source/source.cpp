#include<iostream>
#include<fstream>
#include<string>
#include<cmath>


#define PI 3.141592653589793238462

int main(int argc, char *argv[]) {
	double exact = pow(PI, 2) / 6.0;
	int iti = 0, start = 0, end = 0;
	int step = 0, trun = 0;
	float Sn = 0;
	std::ofstream fout;
	fout.open("data.txt");

	trun = std::stoi(argv[1]);
	step = std::stoi(argv[2]);

	std::cout << "Computing Basel problem, truncated at " << trun << " and output intermediate result in step " << step << '\n';
	std::cout << "Output format: Intermediate step, Computed sum in single precision, Error compared with result from double precision, Error bound computed in double precision\n";
	
	fout.precision(10);
	while (iti < trun) {
		start = iti, end = iti + step;
		for (iti=start; iti < end; iti++) {
			Sn += float(1.0) / float((iti + 1)*(iti + 1));
		}
		fout << end << '\t' << Sn << '\t' << exact - double(Sn) << '\t' << double(1.0) / (iti - 1) << '\n';
	}
	fout.close();
}

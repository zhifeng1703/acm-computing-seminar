#pragma once

#include<iostream>
#include<fstream>

namespace mtx {
	template<typename Type>
	class matrix {
	private:
		Type* data;
		int row;
		int col;
		bool check_indices(int i, int j) const {
			if (i < 0 || j < 0 || i >= row || j>= col) {
				std::cout << "Invalid index encountered with i = " << i
					<< "\t j = " << j << "\nMatrix size is " << row
					<< " * " << col<<"\n";
				return false;
			}
			return true;
		}
		// This function is only used for debug purpose and therefore
		// it should be inaccessible from outside.
	public:
		// Default constructor
		matrix() {
			row = 1;
			col = 1;
			data = new Type[row*col];
			memset(data, 0, (row*col) * sizeof(Type));
		}

		// Customized constructor by dimension
		matrix(int m,int n) : row(m),col(n) { 
			// Shorthand syntax for assigning m to row and n to col
			data = new Type[this->row*this->col];
			memset(data, 0, (this->row*this->col) * sizeof(Type));
		}

		// Copy constructor
		matrix(const matrix & src) : matrix(src.row, src.col) {
			// Shorthand synatas for calling the constructor by dimension
			// with arguments src.row and src.col

			// Entry-wise copy.
			/*
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					(*this)(i, j) = src(i, j);
				}
			}
			*/

			// Memory level copy. Note that it assume the data are stored
			// in a continuous memory space.
			memcpy(this->data, src.data, (row*col) * sizeof(Type));
			
		}
		
		~matrix() { delete[] data; }

		int n_rows() const { return row; }
		int n_cols() const { return col; }

		// Element accessor.
		Type & operator()(int i, int j) const {
			// Note that it is important to return Type &, i.e. the address. 
			// By returning address, you gain access to entries on memory level,
			// It means you can change these entries outside the class, i.e.,
			// A(i,j)=1.0 make sense when Type & is returned.
#ifndef NDEBUG
			if(!check_indices(i, 0))
				exit(1);
#endif // !NDEBUG

			// Data stored in row-major.
			int k = i* this->col + j;

			return this->data[k];
		}

		// Row accessor.
		Type* operator()(int i) const {
#ifndef NDEBUG
			if(!check_indices(i, 0))
				exit(1);
#endif // !NDEBUG
			return this->data + i * this->col;
		}

		// Overload assignment operator
		matrix<Type> & operator = (const matrix<Type> & src) {
			if (data != nullptr)
				delete[] data;
			if (row != src.row || col != src.col) {
#ifndef NDEBUG
				std::cout << "Warning! Dimension of assigned matrix does not match.\n";
				std::cout << "Assigning " << src.row << " by " << src.col << " matrix to "
					<< row << " by " << col << " matrix.\n";
#endif // !NDEBUG
				row = src.row;
				col = src.col;
			}
			data = new Type[row*col];
			memcpy(data, src.data, (row*col) * sizeof(Type));
			return *this;
		}

		friend std::ostream & operator << (std::ostream & os,const matrix<Type>& A){
			for (int i = 0; i < A.row; i++) {
				for (int j = 0; j < A.col; j++) {
					os << A(i, j);
					if (j != (A.col - 1))
						os << ' ';
					else
						os << '\n';
				}
			}
			return os;
		}

		friend std::fstream & operator << (std::fstream & fs, const matrix<Type>& A) {
			for (int i = 0; i < A.row; i++) {
				for (int j = 0; j < A.col; j++) {
					os << A(i, j);
					if (j != (A.col - 1))
						fs << ' ';
					else
						fs << '\n';
				}
			}
			return os;
		}
	};
}

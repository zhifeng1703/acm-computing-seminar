#include<iostream>
#include"myMatrix.h"

#define NDEBUG

using mtx::matrix;
using namespace std;

template<typename Type>
Type norm(const Type* src, int length, int p) {
	Type sum = 0;
	for (int i = 0; i < length; i++) {
		sum = sum + Type(pow(abs(src[i]), p));
	}
	sum = pow(sum, 1.0 / p);
	return sum;
}

int main() {
	matrix<double> A(2, 2);
	A(0, 0) = 1.0;
	A(0, 1) = 2.0;
	cout << norm(A(0), 2, 2)<<"\n";
	cout << norm(A(1), 2, 2) << "\n";

	matrix<double> B(5, 3);

	cout <<"Matrix A:\n"<< A << "Matrix B:\n" << B;

	fstream fs;
	fs.open("test.txt", ios::out);
	B = A;
	fs << "Matrix A:\n" << A << "Matrix B:\n" << B;
	fs.close();
}